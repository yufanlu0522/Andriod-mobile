/**
 * @author Yufan Lu, Yuting Long
 * AndrewID: yufanlu, yutinglo
 */
package edu.heinz.ds.androidcurrencyscoop;

public class ResponseMessage {
    String from;
    String to;
    double amount;
    String result;
}
