/**
 * @author Yufan Lu, Yuting Long
 * AndrewID: yufanlu, yutinglo
 */
package edu.heinz.ds.androidcurrencyscoop;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

public class Currencyscoop extends AppCompatActivity {
    Currencyscoop me = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*
            Create a Currencyscoop object
         */
        final Currencyscoop ma = this;

        /*
         * Find the "submit" button, and add a listener to it
         */
        Button submitButton = (Button)findViewById(R.id.submit);

        /*
        Add a dropdown selector for currencyCodeFrom
         */
        Spinner currencyCodeFromDropdown = findViewById(R.id.currencyCodeFrom);
        // currency code list
        String[] items = new String[]{"CNY", "USD", "EUR", "GBP", "AUD", "CAD", "JPY", "HKD", "INR", "ZAR", "TWD", "MOP", "KRW", "THB", "NZD", "SGD"};
        ArrayAdapter<String> currencyCodeFromAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        currencyCodeFromDropdown.setAdapter(currencyCodeFromAdapter);

        /*
        Add a dropdown selector for currencyCodeTo
         */
        Spinner currencyCodeToDropdown = findViewById(R.id.currencyCodeTo);
        ArrayAdapter<String> currencyCodeToAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        currencyCodeToDropdown.setAdapter(currencyCodeToAdapter);

        // Add a listener to the send button
        submitButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View viewParam) {
                /*
                Get parameters from android views
                 */
                String currencyCodeFrom = currencyCodeFromDropdown.getSelectedItem().toString();
                String currencyCodeTo = currencyCodeToDropdown.getSelectedItem().toString();
                String currencyAmount = ((EditText)findViewById(R.id.currencyAmount)).getText().toString();

                /*
                Print out parameters
                 */
                System.out.println("currencyCodeFrom = " + currencyCodeFrom);
                System.out.println("currencyCodeTo = " + currencyCodeTo);
                System.out.println("currencyAmount = " + currencyAmount);

                /*
                data validation check
                 */
                if(currencyAmount.trim().equals("")){
                    TextView valueView = (TextView)findViewById(R.id.valueText);
                    valueView.setText("Please enter amount");
                    valueView.setVisibility(View.VISIBLE);
                    return;
                }
                /*
                call search function in GetCurrencyConversion.java
                 */
                GetCurrencyConversion gp = new GetCurrencyConversion();
                gp.search(currencyCodeFrom, currencyCodeTo, currencyAmount, me, ma); // Done asynchronously in another thread.  It calls ip.pictureReady() in this thread when complete.
            }
        });
    }

    /*
     * This is called by the GetCurrencyConversion object when the response JSON is ready.
     */
    public void valueReady(String someJSON) {
        System.out.println("JSON" + someJSON);
        /*
        Parse JSON
         */
        TextView valueView = (TextView)findViewById(R.id.valueText);
        Gson gson = new Gson();
        ResponseMessage incommingMsg = gson.fromJson(someJSON,ResponseMessage.class);
        String value = String.valueOf(incommingMsg.result);

        /*
        Check returned JSON
         */
        if (value != null) {
            valueView.setText(value);
            valueView.setVisibility(View.VISIBLE);
        } else {
            System.out.println("Return JSON is null");
        }
}
}
